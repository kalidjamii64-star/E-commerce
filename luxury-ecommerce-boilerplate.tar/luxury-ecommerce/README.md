# Luxury Multi-Vendor E-Commerce — Boilerplate

Next.js (App Router) + TypeScript + Tailwind + Prisma/PostgreSQL scaffold.

## Stack

- **Frontend:** Next.js 14 (App Router), TypeScript, Tailwind CSS
- **Backend:** Next.js Route Handlers (Node.js/TypeScript), modular under `src/app/api/*`
- **Database:** PostgreSQL via Prisma ORM
- **Spatial:** Three.js canvas stub (`src/components/spatial`), ready for glTF/WebXR asset loading
- **Concierge:** "Liza" chat UI stub (`src/components/liza`) + `/api/liza` route
- **Auth:** WebAuthn credential schema (`WebAuthnCredential` model) — authentication only, not payment settlement

## Getting started

```bash
npm install
cp .env.example .env      # then set DATABASE_URL to your local Postgres instance
npx prisma migrate dev --name init
npm run prisma:seed       # optional demo data
npm run dev
```

Visit `http://localhost:3000`.

## Routes

| Path | Purpose |
|---|---|
| `/` | Home — bento grid, featured 3D product, Liza concierge |
| `/vendor-hub` | Merchant list (reads `Merchant` table) |
| `/checkout` | Cart summary + WebAuthn verify stub + place-order action |
| `/api/products` | GET (list), POST (create) |
| `/api/vendors` | GET (list), POST (create) |
| `/api/checkout` | POST — creates a pending `Transaction` from cart items |
| `/api/liza` | POST — stub concierge reply (wire to a real model provider) |

## What's real vs. stubbed

**Functional today:**
- Prisma schema + migrations against a real Postgres database
- All three pages render and query live data (vendor-hub, checkout math)
- REST-style CRUD routes for products/vendors, transaction creation with fee calculation

**Intentionally stubbed (by design, per spec):**
- `SpatialCanvas` renders a placeholder wireframe, not a loaded 3D asset — swap in a glTF loader against `Product.model3dUrl` when ready
- `LizaConcierge` calls `/api/liza`, which returns a canned reply — connect it to a real model provider
- WebAuthn UI button is present but disabled — needs a real `@simplewebauthn/server` (or similar) registration/assertion flow
- Payment capture/settlement is not implemented — `Transaction.status` stops at `PENDING`; integrate a real payment processor before going live

## Note on terminology

The `WebAuthnCredential` model and related fields are scoped strictly to **authentication** (verifying it's really you via Face ID/Touch ID), not to payment **settlement or clearing**, which is a distinct concern typically handled by a PCI-compliant payment processor. Keep that boundary explicit as you build out the payments layer.
