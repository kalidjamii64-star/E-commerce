/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        obsidian: {
          950: "#07080a",
          900: "#0d0f13",
          800: "#15181e",
          700: "#1e222b",
        },
        accent: {
          DEFAULT: "#c9a86a", // muted champagne gold, not the default terracotta/acid-green
          light: "#e2cd9c",
          dim: "#8a7448",
        },
      },
      backdropBlur: {
        xs: "2px",
      },
      borderRadius: {
        bento: "1.25rem",
      },
      boxShadow: {
        glass: "0 8px 32px 0 rgba(0, 0, 0, 0.45)",
      },
    },
  },
  plugins: [],
};
