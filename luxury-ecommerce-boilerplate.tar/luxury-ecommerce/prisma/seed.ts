import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const user = await prisma.user.upsert({
    where: { email: "demo-merchant@example.com" },
    update: {},
    create: {
      email: "demo-merchant@example.com",
      name: "Demo Merchant Owner",
      role: "MERCHANT_ADMIN",
    },
  });

  const merchant = await prisma.merchant.upsert({
    where: { userId: user.id },
    update: {},
    create: {
      userId: user.id,
      brandName: "Atelier Noir",
      description: "Seed merchant for local development.",
      status: "VERIFIED",
    },
  });

  await prisma.product.createMany({
    data: [
      {
        merchantId: merchant.id,
        title: "Obsidian Leather Tote",
        description: "Hand-finished calfskin tote.",
        priceCents: 189000,
        inventoryQty: 12,
        arEnabled: true,
      },
      {
        merchantId: merchant.id,
        title: "Champagne Silk Scarf",
        description: "100% mulberry silk, hand-rolled edges.",
        priceCents: 42000,
        inventoryQty: 40,
      },
    ],
    skipDuplicates: true,
  });

  console.log("Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
