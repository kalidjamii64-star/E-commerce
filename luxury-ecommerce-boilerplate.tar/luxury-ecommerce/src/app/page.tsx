import { BentoGrid, BentoCell } from "@/components/bento/BentoGrid";
import { SpatialCanvas } from "@/components/spatial/SpatialCanvas";
import { LizaConcierge } from "@/components/liza/LizaConcierge";
import Link from "next/link";

export default function HomePage() {
  return (
    <main className="pb-24">
      <header className="glass-panel m-4 flex items-center justify-between rounded-bento px-5 py-4 sm:m-6">
        <span className="text-lg font-medium tracking-tight">Marketplace</span>
        <nav className="flex gap-4 text-sm text-neutral-300">
          <Link href="/vendor-hub" className="hover:text-accent">
            Vendor Hub
          </Link>
          <Link href="/checkout" className="hover:text-accent">
            Checkout
          </Link>
        </nav>
      </header>

      <BentoGrid>
        <BentoCell span={4} rowSpan={2}>
          <h1 className="text-2xl font-semibold tracking-tight">
            Featured product
          </h1>
          <p className="mb-3 text-sm text-neutral-400">
            360° preview — spatial canvas stub
          </p>
          <SpatialCanvas />
        </BentoCell>

        <BentoCell span={2}>
          <h2 className="mb-1 text-sm font-medium text-neutral-300">
            Verified merchants
          </h2>
          <p className="text-3xl font-semibold">—</p>
          <p className="text-xs text-neutral-500">Live once vendors onboard</p>
        </BentoCell>

        <BentoCell span={2}>
          <h2 className="mb-1 text-sm font-medium text-neutral-300">
            Live GMV
          </h2>
          <p className="text-3xl font-semibold">—</p>
          <p className="text-xs text-neutral-500">Populated from Transactions</p>
        </BentoCell>

        <BentoCell span={6}>
          <h2 className="mb-2 text-sm font-medium text-neutral-300">
            Ask Liza
          </h2>
          <div className="h-72">
            <LizaConcierge />
          </div>
        </BentoCell>
      </BentoGrid>
    </main>
  );
}
