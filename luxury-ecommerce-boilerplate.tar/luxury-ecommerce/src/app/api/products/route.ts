import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const products = await prisma.product.findMany({
    include: { merchant: { select: { brandName: true } } },
    orderBy: { createdAt: "desc" },
    take: 50,
  });
  return NextResponse.json(products);
}

export async function POST(req: NextRequest) {
  const body = await req.json();

  const product = await prisma.product.create({
    data: {
      merchantId: body.merchantId,
      title: body.title,
      description: body.description ?? null,
      priceCents: body.priceCents,
      currency: body.currency ?? "USD",
      inventoryQty: body.inventoryQty ?? 0,
      model3dUrl: body.model3dUrl ?? null,
      model3dFormat: body.model3dFormat ?? null,
      arEnabled: body.arEnabled ?? false,
      posterImageUrl: body.posterImageUrl ?? null,
    },
  });

  return NextResponse.json(product, { status: 201 });
}
