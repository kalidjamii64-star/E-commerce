import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

/**
 * POST /api/checkout
 * Creates a pending transaction from cart items. Payment capture
 * and WebAuthn verification are stubbed — wire up your payment
 * processor and WebAuthn assertion check before going live.
 */
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { userId, items } = body as {
    userId: string;
    items: { productId: string; quantity: number }[];
  };

  if (!userId || !items?.length) {
    return NextResponse.json({ error: "Missing userId or items" }, { status: 400 });
  }

  const products = await prisma.product.findMany({
    where: { id: { in: items.map((i) => i.productId) } },
    include: { merchant: true },
  });

  const subtotalCents = items.reduce((sum, item) => {
    const product = products.find((p) => p.id === item.productId);
    return sum + (product ? product.priceCents * item.quantity : 0);
  }, 0);

  // Uses the first matched product's merchant take rate as a stand-in;
  // a real multi-merchant cart should split fees per line item/merchant.
  const takeRateBps = products[0]?.merchant.takeRateBps ?? 1000;
  const platformFeeCents = Math.round((subtotalCents * takeRateBps) / 10000);
  const totalCents = subtotalCents;

  const transaction = await prisma.transaction.create({
    data: {
      userId,
      subtotalCents,
      platformFeeCents,
      totalCents,
      status: "PENDING",
      webauthnVerified: false,
      items: {
        create: items.map((item) => {
          const product = products.find((p) => p.id === item.productId)!;
          return {
            productId: item.productId,
            quantity: item.quantity,
            unitPriceCents: product.priceCents,
          };
        }),
      },
    },
    include: { items: true },
  });

  return NextResponse.json(transaction, { status: 201 });
}
