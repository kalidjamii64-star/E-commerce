import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";

const requestSchema = z.object({
  messages: z.array(
    z.object({
      role: z.enum(["user", "assistant"]),
      content: z.string(),
    })
  ),
});

/**
 * POST /api/liza
 * Stub endpoint for the Liza AI Concierge conversational layer.
 * Replace the canned response below with a call to your model
 * provider (e.g. Anthropic API) once LIZA_API_KEY is configured.
 */
export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = requestSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const lastUserMessage = parsed.data.messages.at(-1)?.content ?? "";

  // Placeholder logic — no live model call yet.
  const reply = lastUserMessage
    ? `(stub) I heard: "${lastUserMessage}". Liza's conversational engine isn't wired up yet.`
    : "I'm here whenever you're ready.";

  return NextResponse.json({ reply });
}
