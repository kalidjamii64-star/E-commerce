import { prisma } from "@/lib/prisma";
import { BentoGrid, BentoCell } from "@/components/bento/BentoGrid";
import Link from "next/link";

export default async function VendorHubPage() {
  const merchants = await prisma.merchant.findMany({
    include: { _count: { select: { products: true } } },
    orderBy: { createdAt: "desc" },
    take: 20,
  });

  return (
    <main className="pb-24">
      <header className="glass-panel m-4 flex items-center justify-between rounded-bento px-5 py-4 sm:m-6">
        <Link href="/" className="text-sm text-neutral-400 hover:text-accent">
          ← Marketplace
        </Link>
        <span className="text-lg font-medium tracking-tight">Vendor Hub</span>
      </header>

      <BentoGrid>
        <BentoCell span={6}>
          <h1 className="mb-1 text-xl font-semibold">Merchants</h1>
          <p className="mb-4 text-sm text-neutral-400">
            {merchants.length === 0
              ? "No merchants onboarded yet."
              : `${merchants.length} merchant(s) on the platform`}
          </p>

          {merchants.length === 0 ? (
            <div className="rounded-xl border border-dashed border-white/10 p-6 text-center text-sm text-neutral-500">
              Onboard your first merchant via POST /api/vendors.
            </div>
          ) : (
            <ul className="divide-y divide-white/5">
              {merchants.map((m) => (
                <li key={m.id} className="flex items-center justify-between py-3">
                  <div>
                    <p className="font-medium">{m.brandName}</p>
                    <p className="text-xs text-neutral-500">
                      {m._count.products} product(s) · {m.status.toLowerCase()}
                    </p>
                  </div>
                  <span className="text-xs text-neutral-400">
                    {(m.takeRateBps / 100).toFixed(1)}% take rate
                  </span>
                </li>
              ))}
            </ul>
          )}
        </BentoCell>
      </BentoGrid>
    </main>
  );
}
