import { BentoGrid, BentoCell } from "@/components/bento/BentoGrid";
import Link from "next/link";

export default function CheckoutPage() {
  return (
    <main className="pb-24">
      <header className="glass-panel m-4 flex items-center justify-between rounded-bento px-5 py-4 sm:m-6">
        <Link href="/" className="text-sm text-neutral-400 hover:text-accent">
          ← Marketplace
        </Link>
        <span className="text-lg font-medium tracking-tight">Checkout</span>
      </header>

      <BentoGrid>
        <BentoCell span={4}>
          <h1 className="mb-4 text-xl font-semibold">Order summary</h1>
          <div className="rounded-xl border border-dashed border-white/10 p-6 text-center text-sm text-neutral-500">
            Cart is empty. Wire this section to your cart state and POST it to
            /api/checkout.
          </div>
        </BentoCell>

        <BentoCell span={2}>
          <h2 className="mb-2 text-sm font-medium text-neutral-300">
            Verify &amp; pay
          </h2>
          <p className="mb-4 text-xs text-neutral-500">
            Face ID / Touch ID authenticates your account via WebAuthn. Payment
            capture is handled separately by your payment processor.
          </p>
          <button
            disabled
            className="w-full rounded-xl bg-accent px-4 py-3 text-sm font-medium text-obsidian-950 opacity-50"
          >
            Verify with Face ID / Touch ID
          </button>
        </BentoCell>
      </BentoGrid>

      {/* Thumb-zone action bar for mobile checkout flow */}
      <div className="thumb-zone-bar">
        <button
          disabled
          className="w-full rounded-xl bg-accent px-4 py-3 text-sm font-semibold text-obsidian-950 opacity-50"
        >
          Place order
        </button>
      </div>
    </main>
  );
}
