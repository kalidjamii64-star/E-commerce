"use client";

import { useState } from "react";

type Message = { role: "user" | "assistant"; content: string };

/**
 * Stub conversational UI for the "Liza" concierge layer.
 * Wired to POST /api/liza. Swap the fetch call for a streaming
 * connection to your model provider when ready.
 */
export function LizaConcierge() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hi, I'm Liza. What are you shopping for today?" },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  async function sendMessage() {
    const text = input.trim();
    if (!text || loading) return;

    const nextMessages: Message[] = [...messages, { role: "user", content: text }];
    setMessages(nextMessages);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/liza", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: nextMessages }),
      });
      const data = await res.json();
      setMessages((prev) => [...prev, { role: "assistant", content: data.reply }]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "Something went wrong reaching Liza. Try again." },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="glass-panel flex h-full flex-col p-4">
      <div className="mb-3 flex-1 space-y-2 overflow-y-auto">
        {messages.map((m, i) => (
          <div
            key={i}
            className={
              m.role === "user"
                ? "ml-auto max-w-[80%] rounded-2xl bg-accent/20 px-3 py-2 text-sm"
                : "mr-auto max-w-[80%] rounded-2xl bg-white/5 px-3 py-2 text-sm"
            }
          >
            {m.content}
          </div>
        ))}
        {loading && <div className="mr-auto text-xs text-neutral-400">Liza is thinking…</div>}
      </div>
      <div className="flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          placeholder="Ask Liza anything…"
          className="flex-1 rounded-xl border border-white/10 bg-obsidian-900/80 px-3 py-2 text-sm outline-none focus:border-accent/50"
        />
        <button
          onClick={sendMessage}
          disabled={loading}
          className="rounded-xl bg-accent px-4 py-2 text-sm font-medium text-obsidian-950 disabled:opacity-50"
        >
          Send
        </button>
      </div>
    </div>
  );
}
