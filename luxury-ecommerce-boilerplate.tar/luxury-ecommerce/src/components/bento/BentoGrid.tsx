import { clsx } from "clsx";
import type { ReactNode } from "react";

export function BentoGrid({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={clsx(
        "grid grid-cols-2 gap-3 p-4",
        "sm:grid-cols-4 sm:gap-4 sm:p-6",
        "lg:grid-cols-6",
        className
      )}
    >
      {children}
    </div>
  );
}

export function BentoCell({
  children,
  span = 1,
  rowSpan = 1,
  className,
}: {
  children: ReactNode;
  span?: 1 | 2 | 3 | 4 | 6;
  rowSpan?: 1 | 2;
  className?: string;
}) {
  const colSpanClass = {
    1: "col-span-2 sm:col-span-1",
    2: "col-span-2",
    3: "col-span-2 sm:col-span-3",
    4: "col-span-2 sm:col-span-4",
    6: "col-span-2 sm:col-span-4 lg:col-span-6",
  }[span];

  const rowSpanClass = rowSpan === 2 ? "row-span-2" : "row-span-1";

  return (
    <div
      className={clsx(
        "glass-panel glass-panel-hover p-4 sm:p-5",
        colSpanClass,
        rowSpanClass,
        className
      )}
    >
      {children}
    </div>
  );
}
