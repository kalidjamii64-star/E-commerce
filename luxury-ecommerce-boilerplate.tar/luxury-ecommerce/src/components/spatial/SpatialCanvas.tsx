"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";

/**
 * Stub spatial canvas for future 360°/WebXR product rendering.
 * Currently renders a placeholder rotating wireframe so the layout
 * and mount lifecycle are wired up. Swap the geometry/loader logic
 * for a real glTF loader + WebXR session when the asset pipeline
 * (Product.model3dUrl) is ready.
 */
export function SpatialCanvas({
  posterImageUrl,
  className,
}: {
  posterImageUrl?: string | null;
  className?: string;
}) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.z = 4;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // Placeholder geometry — replace with glTF-loaded product mesh.
    const geometry = new THREE.IcosahedronGeometry(1.4, 0);
    const material = new THREE.MeshBasicMaterial({
      color: 0xc9a86a,
      wireframe: true,
      transparent: true,
      opacity: 0.6,
    });
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    let frameId: number;
    const animate = () => {
      mesh.rotation.x += 0.003;
      mesh.rotation.y += 0.004;
      renderer.render(scene, camera);
      frameId = requestAnimationFrame(animate);
    };
    animate();

    const handleResize = () => {
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener("resize", handleResize);
      geometry.dispose();
      material.dispose();
      renderer.dispose();
      container.removeChild(renderer.domElement);
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className={className ?? "relative h-64 w-full overflow-hidden rounded-bento"}
      aria-label={posterImageUrl ? "3D product preview" : "3D product preview (placeholder)"}
    />
  );
}
